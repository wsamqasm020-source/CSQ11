"""
تطبيق تسجيل الحضور بالـ QR
Flask Web Application
"""
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, flash
import qrcode
import io
import base64
import os
from datetime import datetime
from database import (
    init_database, add_student, get_student_by_code, get_student_by_id,
    get_all_students, add_subject, get_all_subjects, get_subjects_by_department,
    record_attendance, get_attendance_by_subject, get_attendance_by_student,
    get_today_attendance_stats, delete_student, delete_subject,
    get_student_group_name
)

app = Flask(__name__)
app.secret_key = 'qr_attendance_secret_key_2026'


def generate_qr_code(data, teacher_name=None):
    """توليد QR code من البيانات مع إضافة اسم الأستاذ في الصورة"""
    qr = qrcode.QRCode(
        version=3,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)
    
    # إنشاء الصورة
    from PIL import Image, ImageDraw, ImageFont
    
    # حجم QR code
    qr_img = qr.make_image(fill_color="black", back_color="white")
    
    # إضافة اسم الأستاذ أسفل QR code
    if teacher_name:
        # إنشاء صورة أكبر لوضع النص
        qr_width, qr_height = qr_img.size
        text_height = 60
        new_img = Image.new('RGB', (qr_width, qr_height + text_height), 'white')
        new_img.paste(qr_img, (0, 0))
        
        # إضافة النص
        draw = ImageDraw.Draw(new_img)
        
        # محاولة استخدام خط عربي
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
        except:
            font = ImageFont.load_default()
        
        # كتابة اسم الأستاذ
        text = f"الأستاذ: {teacher_name}"
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_x = (qr_width - text_width) // 2
        text_y = qr_height + 15
        
        draw.text((text_x, text_y), text, fill='black', font=font)
        
        return new_img
    
    return qr_img


def qr_to_base64(img):
    """تحويل صورة QR إلى base64"""
    buffer = io.BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    img_str = base64.b64encode(buffer.getvalue()).decode()
    return f"data:image/png;base64,{img_str}"


def generate_student_code(department, teacher_name, group_name):
    """توليد رقم طالب فريد"""
    # أخذ أول حرفين من اسم القسم
    dept_prefix = department[:2].upper() if department else 'XX'
    
    # أخذ أول حرفين من اسم الأستاذ
    teacher_prefix = teacher_name[:2].upper() if teacher_name else 'XX'
    
    # أخذ أول حرفين من اسم الكروب
    group_prefix = group_name[:2].upper() if group_name else 'XX'
    
    prefix = f"{dept_prefix}{teacher_prefix}{group_prefix}"
    
    # الحصول على آخر رقم
    students = get_all_students()
    max_num = 0
    for student in students:
        if student['student_code'].startswith(prefix):
            try:
                num = int(student['student_code'][-3:])
                max_num = max(max_num, num)
            except:
                pass
    
    new_num = max_num + 1
    return f"{prefix}{new_num:03d}"


@app.route('/')
def index():
    """الصفحة الرئيسية"""
    return render_template('index.html')


@app.route('/generate')
def generate_page():
    """صفحة توليد QR"""
    return render_template('generate.html')


@app.route('/api/generate-qr', methods=['POST'])
def api_generate_qr():
    """API لتوليد QR code"""
    data = request.json
    full_name = data.get('full_name')
    department = data.get('department')
    teacher_name = data.get('teacher_name')
    group_name = data.get('group_name')
    
    if not all([full_name, department, teacher_name, group_name]):
        return jsonify({'success': False, 'message': 'جميع الحقول مطلوبة'}), 400
    
    # توليد رقم الطالب
    student_code = generate_student_code(department, teacher_name, group_name)
    
    # بيانات QR
    qr_data = f"CODE:{student_code}|NAME:{full_name}|DEPT:{department}|TEACHER:{teacher_name}|GROUP:{group_name}"
    
    # توليد QR code مع اسم الأستاذ في الصورة
    qr_img = generate_qr_code(qr_data, teacher_name)
    qr_base64 = qr_to_base64(qr_img)
    
    # حفظ الطالب في قاعدة البيانات
    student_id = add_student(full_name, department, teacher_name, group_name, student_code, qr_data)
    
    if student_id:
        return jsonify({
            'success': True,
            'student_id': student_id,
            'student_code': student_code,
            'qr_code': qr_base64,
            'qr_data': qr_data
        })
    else:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء حفظ البيانات'}), 500


@app.route('/scanner')
def scanner_page():
    """صفحة ماسح QR"""
    subjects = get_all_subjects()
    return render_template('scanner.html', subjects=subjects)


@app.route('/api/scan-qr', methods=['POST'])
def api_scan_qr():
    """API لمسح QR code وتسجيل الحضور"""
    data = request.json
    qr_data = data.get('qr_data')
    subject_id = data.get('subject_id')
    
    if not qr_data or not subject_id:
        return jsonify({'success': False, 'message': 'بيانات غير كاملة'}), 400
    
    # استخراج رقم الطالب من بيانات QR
    try:
        # البحث عن الطالب باستخدام بيانات QR
        student = None
        students = get_all_students()
        for s in students:
            if s['qr_code'] == qr_data or qr_data.startswith(f"CODE:{s['student_code']}"):
                student = s
                break
        
        if not student:
            # محاولة استخراج رقم الطالب من البيانات
            if 'CODE:' in qr_data:
                code_start = qr_data.find('CODE:') + 5
                code_end = qr_data.find('|', code_start)
                if code_end == -1:
                    code_end = len(qr_data)
                student_code = qr_data[code_start:code_end]
                student = get_student_by_code(student_code)
        
        if not student:
            return jsonify({'success': False, 'message': 'الطالب غير موجود'}), 404
        
        # الحصول على اسم الكروب من الطالب
        group_name = student['group_name']
        
        # تسجيل الحضور
        success = record_attendance(student['id'], subject_id, group_name)
        
        if success:
            # الحصول على معلومات المادة
            subjects = get_all_subjects()
            subject = next((s for s in subjects if s['id'] == subject_id), None)
            
            return jsonify({
                'success': True,
                'message': f"تم تسجيل حضور {student['full_name']} بنجاح",
                'student': student,
                'subject': subject,
                'group_name': group_name
            })
        else:
            return jsonify({
                'success': False,
                'message': 'الطالب مسجل حضور مسبقاً لهذا اليوم في هذه المادة'
            }), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في معالجة البيانات: {str(e)}'}), 500


@app.route('/students')
def students_page():
    """صفحة قائمة الطلاب"""
    students = get_all_students()
    return render_template('students.html', students=students)


@app.route('/student/<int:student_id>')
def student_detail(student_id):
    """صفحة تفاصيل الطالب"""
    student = get_student_by_id(student_id)
    if not student:
        flash('الطالب غير موجود', 'error')
        return redirect(url_for('students_page'))
    
    attendance = get_attendance_by_student(student_id)
    
    # توليد QR code مع اسم الأستاذ
    qr_img = generate_qr_code(student['qr_code'], student['teacher_name'])
    qr_base64 = qr_to_base64(qr_img)
    
    return render_template('student_detail.html', 
                         student=student, 
                         attendance=attendance,
                         qr_code=qr_base64)


@app.route('/subjects')
def subjects_page():
    """صفحة المواد"""
    subjects = get_all_subjects()
    return render_template('subjects.html', subjects=subjects)


@app.route('/api/add-subject', methods=['POST'])
def api_add_subject():
    """API لإضافة مادة جديدة"""
    data = request.json
    name = data.get('name')
    code = data.get('code')
    department = data.get('department')
    teacher_name = data.get('teacher_name')
    
    if not all([name, code, department, teacher_name]):
        return jsonify({'success': False, 'message': 'جميع الحقول مطلوبة'}), 400
    
    subject_id = add_subject(name, code, department, teacher_name)
    
    if subject_id:
        return jsonify({'success': True, 'subject_id': subject_id})
    else:
        return jsonify({'success': False, 'message': 'رمز المادة موجود مسبقاً'}), 400


@app.route('/attendance')
def attendance_page():
    """صفحة سجل الحضور"""
    subjects = get_all_subjects()
    today = datetime.now().strftime('%Y-%m-%d')
    
    # إحصائيات اليوم
    today_stats = get_today_attendance_stats()
    
    return render_template('attendance.html', 
                         subjects=subjects,
                         today=today,
                         today_stats=today_stats)


@app.route('/api/attendance/<int:subject_id>')
def api_get_attendance(subject_id):
    """API للحصول على سجل الحضور"""
    date = request.args.get('date')
    attendance = get_attendance_by_subject(subject_id, date)
    
    # إضافة معلومات المادة
    subjects = get_all_subjects()
    subject = next((s for s in subjects if s['id'] == subject_id), None)
    
    return jsonify({
        'success': True, 
        'attendance': attendance,
        'subject': subject
    })


@app.route('/api/delete-student/<int:student_id>', methods=['DELETE'])
def api_delete_student(student_id):
    """API لحذف طالب"""
    delete_student(student_id)
    return jsonify({'success': True})


@app.route('/api/delete-subject/<int:subject_id>', methods=['DELETE'])
def api_delete_subject(subject_id):
    """API لحذف مادة"""
    delete_subject(subject_id)
    return jsonify({'success': True})


@app.route('/api/get-subjects')
def api_get_subjects():
    """API للحصول على المواد"""
    department = request.args.get('department')
    
    if department:
        subjects = get_subjects_by_department(department)
    else:
        subjects = get_all_subjects()
    
    return jsonify({'success': True, 'subjects': subjects})


if __name__ == '__main__':
    # تهيئة قاعدة البيانات
    init_database()
    
    # تشغيل التطبيق
    app.run(debug=True, host='0.0.0.0', port=5000)
