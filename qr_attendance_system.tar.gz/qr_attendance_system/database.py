"""
قاعدة بيانات نظام تسجيل الحضور بالـ QR
"""
import sqlite3
import os
from datetime import datetime

DATABASE_PATH = 'attendance.db'


def get_db_connection():
    """الحصول على اتصال بقاعدة البيانات"""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_database():
    """تهيئة قاعدة البيانات وإنشاء الجداول"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # جدول الطلاب - تم التعديل
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            department TEXT NOT NULL,
            teacher_name TEXT NOT NULL,
            group_name TEXT NOT NULL,
            student_code TEXT UNIQUE NOT NULL,
            qr_code TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # جدول المواد - تم إضافة اسم الأستاذ
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            code TEXT UNIQUE NOT NULL,
            department TEXT NOT NULL,
            teacher_name TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # جدول الحضور - تم التعديل
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            subject_id INTEGER NOT NULL,
            attendance_date DATE NOT NULL,
            group_name TEXT NOT NULL,
            status TEXT DEFAULT 'present',
            FOREIGN KEY (student_id) REFERENCES students (id),
            FOREIGN KEY (subject_id) REFERENCES subjects (id),
            UNIQUE(student_id, subject_id, attendance_date)
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ تم تهيئة قاعدة البيانات بنجاح")


def add_student(full_name, department, teacher_name, group_name, student_code, qr_code):
    """إضافة طالب جديد"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO students (full_name, department, teacher_name, group_name, student_code, qr_code)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (full_name, department, teacher_name, group_name, student_code, qr_code))
        conn.commit()
        student_id = cursor.lastrowid
        conn.close()
        return student_id
    except sqlite3.IntegrityError:
        conn.close()
        return None


def get_student_by_code(student_code):
    """الحصول على طالب برقم الطالب"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM students WHERE student_code = ?', (student_code,))
    student = cursor.fetchone()
    conn.close()
    return dict(student) if student else None


def get_student_by_id(student_id):
    """الحصول على طالب بالمعرف"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM students WHERE id = ?', (student_id,))
    student = cursor.fetchone()
    conn.close()
    return dict(student) if student else None


def get_all_students():
    """الحصول على جميع الطلاب"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM students ORDER BY created_at DESC')
    students = cursor.fetchall()
    conn.close()
    return [dict(student) for student in students]


def add_subject(name, code, department, teacher_name):
    """إضافة مادة جديدة"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO subjects (name, code, department, teacher_name)
            VALUES (?, ?, ?, ?)
        ''', (name, code, department, teacher_name))
        conn.commit()
        subject_id = cursor.lastrowid
        conn.close()
        return subject_id
    except sqlite3.IntegrityError:
        conn.close()
        return None


def get_all_subjects():
    """الحصول على جميع المواد"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM subjects ORDER BY name')
    subjects = cursor.fetchall()
    conn.close()
    return [dict(subject) for subject in subjects]


def get_subjects_by_department(department):
    """الحصول على المواد حسب القسم"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM subjects 
        WHERE department = ?
        ORDER BY name
    ''', (department,))
    subjects = cursor.fetchall()
    conn.close()
    return [dict(subject) for subject in subjects]


def record_attendance(student_id, subject_id, group_name):
    """تسجيل حضور طالب"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    today = datetime.now().strftime('%Y-%m-%d')
    
    try:
        cursor.execute('''
            INSERT INTO attendance (student_id, subject_id, attendance_date, group_name)
            VALUES (?, ?, ?, ?)
        ''', (student_id, subject_id, today, group_name))
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        # الطالب مسجل حضور مسبقاً لهذا اليوم
        conn.close()
        return False


def get_attendance_by_subject(subject_id, date=None):
    """الحصول على سجل الحضور لمادة معينة"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if date:
        cursor.execute('''
            SELECT a.*, s.full_name, s.student_code, s.group_name as student_group
            FROM attendance a
            JOIN students s ON a.student_id = s.id
            WHERE a.subject_id = ? AND a.attendance_date = ?
            ORDER BY a.id DESC
        ''', (subject_id, date))
    else:
        cursor.execute('''
            SELECT a.*, s.full_name, s.student_code, s.group_name as student_group
            FROM attendance a
            JOIN students s ON a.student_id = s.id
            WHERE a.subject_id = ?
            ORDER BY a.attendance_date DESC, a.id DESC
        ''', (subject_id,))
    
    attendance = cursor.fetchall()
    conn.close()
    return [dict(record) for record in attendance]


def get_attendance_by_student(student_id):
    """الحصول على سجل حضور طالب معين"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT a.*, s.name as subject_name, s.code as subject_code, s.teacher_name
        FROM attendance a
        JOIN subjects s ON a.subject_id = s.id
        WHERE a.student_id = ?
        ORDER BY a.attendance_date DESC
    ''', (student_id,))
    attendance = cursor.fetchall()
    conn.close()
    return [dict(record) for record in attendance]


def get_today_attendance_stats():
    """إحصائيات حضور اليوم"""
    conn = get_db_connection()
    cursor = conn.cursor()
    today = datetime.now().strftime('%Y-%m-%d')
    
    cursor.execute('''
        SELECT s.name as subject_name, s.teacher_name, COUNT(*) as count
        FROM attendance a
        JOIN subjects s ON a.subject_id = s.id
        WHERE a.attendance_date = ?
        GROUP BY a.subject_id
    ''', (today,))
    
    stats = cursor.fetchall()
    conn.close()
    return [dict(stat) for stat in stats]


def delete_student(student_id):
    """حذف طالب"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM students WHERE id = ?', (student_id,))
    conn.commit()
    conn.close()
    return True


def delete_subject(subject_id):
    """حذف مادة"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM subjects WHERE id = ?', (subject_id,))
    conn.commit()
    conn.close()
    return True


def get_student_group_name(student_id):
    """الحصول على اسم الكروب للطالب"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT group_name FROM students WHERE id = ?', (student_id,))
    result = cursor.fetchone()
    conn.close()
    return result['group_name'] if result else None
